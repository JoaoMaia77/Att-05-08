﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tratamento_Exeption_20
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_calcular_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_1.Text.Length <= 0)
                throw new Exception("Campo obrigatório Vazio");
                int x = int.Parse(txt_1.Text);
                int y = int.Parse(txt_1.Text);
                x = x / y;
                MessageBox.Show(x.ToString());

            }
            catch(FormatException)
            {
                MessageBox.Show("Erro: Digite apenas Números");
            }
            catch(DivideByZeroException)
            {
                MessageBox.Show("Erro: não é possivel dividir por 0");
            }
            catch (Exception exc)
            {
                MessageBox.Show("Erro: " + exc.Message);
            }
            finally
            {
                MessageBox.Show("O evento click do Button 1 foi adicionado");
            }

            //1 - A) Ocorreu um erro, pois a variavel deverá ser do tipo INT. 
            //2 - A) O erro continua, mas agora o erro é exibido. 

        }
    }
}
